<?php
/*
  Plugin Name: Types Access
  Plugin URI: http://wordpress.org/extend/plugins/types/
  Description: Define custom post types, custom taxonomy and custom fields.
  Author: ICanLocalize
  Author URI: http://wp-types.com
  Version: 0.1
 */

require_once dirname(__FILE__) . '/plus.php';
require_once dirname(__FILE__) . '/embedded.php';