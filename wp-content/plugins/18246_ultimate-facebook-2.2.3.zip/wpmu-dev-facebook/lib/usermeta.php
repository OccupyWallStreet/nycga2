<?php
/**
 * Deprecated.
 */