=== Events ===
Contributors: mohanjith
Tags: events, booking
Requires at least: 3.3
Stable tag: trunk
Tested up to: 3.3.1

Allow your readers to register for events you organize

== Description ==

Allow your readers to register for events you organize

* Please note we will be automatically changing WPMU DEV Google Maps Plugin Settings if installed *

== ChangeLog ==

= 1.0.1 =

* Initial release

= 1.0.0 =

* Initial release

18246-1343677516