<?php
class BUDDYVENTS_Client
{
	private $url 		= false;
	private $apikey		= false;
	private $username 	= false;
	private $data 		= false;
	
	/**
	 * PHP5 style constructor
	 * 
	 * @param string	$url	The URL to the API including all parameters
	 */	
	public function __construct( $url )
	{
		if( ! $url )
			return 'You need to specify an url';
		
		$this->url = $url;
		$this->format = $this->get_format();
	}

	/**
	 * Get the format of the request from the API endpoint URL
	 */	
	private function get_format()
	{
		$url = parse_url( $this->url );
		$url = trim( $url['path'], '/' );
		$url = explode( '/', $url );
		
		unset( $url[0] );
		unset( $url[1] );
		
		$url = array_values( $url );
		
		$no = ( count( (array)$url ) - 1 );
		
		$data = array();
		
		if( $no > 0 )
		{
			for( $i = 0; $i <= $no; $i++ )
			{
				$current = $url[$i];
				
				$next = $i + 1;
				if( ! empty( $url[$next] ) && ! empty( $current ) )
					$data[$current] = $url[$next];
			}
		}
		
		return ( empty( $data['format'] ) ) ? 'json' : $data['format']; 
	}
		
	/**
	 * Set the username for identification purposes
	 * 
	 * @param	string	$username	Your username on the WP site
	 */	
	public function set_username( $username )
	{
		$this->username = $username;
		
		return $this;
	}

	/**
	 * Set the api key for identification purposes
	 * 
	 * @param	string	apikey	Your API key from the WP site
	 */	
	public function set_apikey( $apikey )
	{
		$this->apikey = $apikey;
		
		return $this;
	}	
	
	/**
	 * Set the event data
	 * 
	 * @param	string	identifier	The DB field name from the events table
	 * @param	string	$content	The corresponding content for the DB field name
	 */	
	public function set( $identifier, $content )
	{
		$this->data->{$identifier} = $content;
		
		return $this;
	}
	
	/**
	 * GET event data
	 * 
	 * No events data needs to be specified for this method
	 */	
	public function get()
	{
		if( empty( $this->username ) )
			return 'You need to specify a username.';

		if( empty( $this->apikey ) )
			return 'You need to specify an api key.';

		$data = array(
			'username' => $this->username,
			'apikey' => $this->apikey
		);
		
		return $this->http( $data );
	}

	/**
	 * POST data to a Buddyvents enabled site
	 */	
	public function post()
	{
		if( empty( $this->username ) )
			return 'You need to specify a username.';

		if( empty( $this->apikey ) )
			return 'You need to specify an api key.';

		$data = array(
			'username' => $this->username,
			'apikey' => $this->apikey,
			'data' => $this->{$this->format}( $this->data )
		);
		
		return $this->http( $data );
	}
	
	/**
	 * Does the heavy lifting
	 */	
	private function http( $data )
	{
		$ch = curl_init( $this->url );
		curl_setopt( $ch, CURLOPT_POST, true );
		curl_setopt( $ch, CURLOPT_POSTFIELDS, http_build_query( $data, '', '&' ) );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		$output = curl_exec( $ch );
		$info = curl_getinfo( $ch );
		curl_close( $ch );
		
		if( $info['http_code'] == 200 )
			return $this->{$this->format}( $output, true );
	}
	
	/**
	 * Encode or decode data in JSON format
	 */	
	private function json( $input, $decode = false )
	{
		return ( $decode === true ) ? json_decode( $input ) : json_encode( $input );
	}
}
?>