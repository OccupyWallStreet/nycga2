<?php get_header() ?>

<div class="content-header">

</div>

<div id="content">
	
	<h2><?php _e( 'Change Avatar', 'buddypress' ) ?></h2>
	
	<?php bp_avatar_upload_form() ?>

</div>

<?php get_footer() ?>