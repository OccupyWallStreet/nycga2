<?php
/**
 * 99% of the time /profile/index.php is the default template file loaded when a user hits a member page.
 */
?>