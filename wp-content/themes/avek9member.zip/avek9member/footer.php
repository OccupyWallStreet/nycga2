</div> <!-- end #main -->

<div id="footer">
    <?php printf( __( '%s is proudly powered by <a href="http://mu.wordpress.org">WordPress MU</a> and <a href="http://buddypress.org">BuddyPress</a>', 'buddypress'  ), bloginfo('name') ); ?>. Theme by <a href="http://www.avenuek9.com" title="Avenue K9" target="_blank">AvenueK9</a>. 
</div>

<?php wp_footer(); ?>

</body>

</html>