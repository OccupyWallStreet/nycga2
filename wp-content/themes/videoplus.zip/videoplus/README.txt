VideoPlus WordPress Theme 1.0
http://www.theme-junkie.com/themes/videoplus

INSTALL: 
1. Upload the theme folder /videoplus via FTP to your wp-content/themes/ directory.
2. Go to your WordPress dashboard and activate the VideoPlus theme.
3. Inside your WordPress dashboard, go to Appearance > VideoPlus Theme Options and configure them to your liking.

If you are looking for theme support, please visit http://www.theme-junkie.com/forum/

Thanks,
Theme Junkie Team
Http://theme-junkie.com